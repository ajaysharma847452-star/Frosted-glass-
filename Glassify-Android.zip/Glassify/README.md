# Glassify (Android)
Build: Android Studio me folder open karo > Run. Ya GitHub par push karo, Actions tab se Glassify-debug-apk download karo.
Home screen: Glassify kholo > Clock/Battery widget add karo, Glass wallpaper lagao.
Icons: Nova Launcher > Settings > Look & feel > Icon style > Icon theme > Glassify.
Admin PIN default: 1234
