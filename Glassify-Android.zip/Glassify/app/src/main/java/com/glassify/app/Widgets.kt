package com.glassify.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.widget.RemoteViews

abstract class GlassWidget : AppWidgetProvider() {
    abstract fun build(ctx: Context, w: Int, h: Int, d: Float, t: GTheme): RemoteViews

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) push(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        push(context, appWidgetManager, appWidgetId)
    }

    private fun push(ctx: Context, m: AppWidgetManager, id: Int) {
        val o = m.getAppWidgetOptions(id)
        val d = minOf(ctx.resources.displayMetrics.density, 2f)
        val mw = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).let { if (it < 40) 250 else it }
        val mh = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0).let { if (it < 40) 110 else it }
        m.updateAppWidget(id, build(ctx, (mw * d).toInt(), (mh * d).toInt(), d, Store.active(ctx)))
    }
}

class ClockWidget : GlassWidget() {
    override fun build(ctx: Context, w: Int, h: Int, d: Float, t: GTheme): RemoteViews {
        val v = RemoteViews(ctx.packageName, R.layout.widget_clock)
        v.setImageViewBitmap(R.id.bg, Glass.clockBg(w, h, t, d))
        v.setTextColor(R.id.time, t.ink)
        v.setTextColor(R.id.date, t.ink)
        return v
    }
}

class BatteryWidget : GlassWidget() {
    override fun build(ctx: Context, w: Int, h: Int, d: Float, t: GTheme): RemoteViews {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val pct = if (i == null) 0 else i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / maxOf(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
        val v = RemoteViews(ctx.packageName, R.layout.widget_battery)
        v.setImageViewBitmap(R.id.bg, Glass.batteryBg(w, h, t, d, pct))
        return v
    }
}
