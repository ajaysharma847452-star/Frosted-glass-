package com.glassify.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import org.json.JSONArray
import org.json.JSONObject

data class GTheme(val id: String, val name: String, val wall: Int, val alpha: Int, val border: Int,
                  val radius: Int, val tint: Int, val ink: Int, val custom: Boolean = false)

object Walls {
    val names = listOf("Aurora", "Sunset", "Ocean", "Forest", "Peach", "Mono")
    private val cols = listOf(
        listOf("#1B1446", "#7C5CFF", "#18D3E6", "#FF6BD6"),
        listOf("#2B1032", "#FFB347", "#FF5E7E", "#7B3FE4"),
        listOf("#071A36", "#3DF0D0", "#2F7BFF", "#6A4DFF"),
        listOf("#0A2A22", "#9BE15D", "#00B894", "#0A6B5B"),
        listOf("#5A2A55", "#FFD1A6", "#FF9AA8", "#C58BFF"),
        listOf("#0B0E16", "#3B4560", "#26304A", "#1A2236")
    ).map { r -> r.map { Color.parseColor(it) } }

    fun accent(i: Int) = cols[i][1]

    fun bitmap(w: Int, h: Int, i: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(cols[i][0])
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val spots = listOf(Triple(0.18f, 0.14f, 0.6f), Triple(0.88f, 0.34f, 0.55f), Triple(0.45f, 0.98f, 0.7f))
        for (k in 0..2) {
            val (x, y, r) = spots[k]
            val col = cols[i][k + 1]
            p.shader = RadialGradient(x * w, y * h, r * maxOf(w, h) * 0.8f, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }
        return b
    }
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("glassify", Context.MODE_PRIVATE)
    private val W = Color.WHITE
    val base = listOf(
        GTheme("frost", "Frost Clear", 0, 18, 45, 30, W, W),
        GTheme("night", "Frost Night", 5, 32, 18, 28, Color.parseColor("#0B1020"), W),
        GTheme("sun", "Sunset Glass", 1, 22, 50, 36, Color.parseColor("#FFD9C2"), W),
        GTheme("mint", "Mint Mist", 3, 16, 40, 50, Color.parseColor("#E6FFF5"), W),
        GTheme("sea", "Ocean Pane", 2, 26, 55, 22, W, W),
        GTheme("peach", "Peach Pearl", 4, 34, 60, 32, W, Color.parseColor("#1A1226"))
    )

    fun customs(c: Context): List<GTheme> {
        val a = JSONArray(sp(c).getString("custom", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            GTheme(o.getString("id"), o.getString("name"), o.getInt("wall"), o.getInt("alpha"), o.getInt("border"),
                o.getInt("radius"), o.getInt("tint"), o.getInt("ink"), true)
        }
    }

    private fun put(c: Context, l: List<GTheme>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("wall", it.wall).put("alpha", it.alpha)
                .put("border", it.border).put("radius", it.radius).put("tint", it.tint).put("ink", it.ink))
        }
        sp(c).edit().putString("custom", a.toString()).apply()
    }

    fun save(c: Context, t: GTheme) = put(c, customs(c).filter { it.id != t.id } + t)
    fun delete(c: Context, id: String) = put(c, customs(c).filter { it.id != id })
    fun all(c: Context) = base + customs(c)
    fun active(c: Context): GTheme { val id = sp(c).getString("active", "frost"); return all(c).firstOrNull { it.id == id } ?: base[0] }
    fun setActive(c: Context, id: String) = sp(c).edit().putString("active", id).apply()
    fun pin(c: Context): String = sp(c).getString("pin", "1234") ?: "1234"
    fun setPin(c: Context, p: String) = sp(c).edit().putString("pin", p).apply()
}

object Glass {
    private fun bmp(w: Int, h: Int) = Bitmap.createBitmap(maxOf(1, w), maxOf(1, h), Bitmap.Config.ARGB_8888)

    fun drawTile(c: Canvas, r: RectF, t: GTheme, d: Float) {
        val rad = minOf(r.width(), r.height()) / 2f * (t.radius / 50f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.color = (t.tint and 0x00FFFFFF) or ((t.alpha * 255 / 100) shl 24)
        c.drawRoundRect(r, rad, rad, fill)
        val hl = Paint(Paint.ANTI_ALIAS_FLAG)
        hl.shader = LinearGradient(r.left, r.top, r.right, r.bottom, Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, hl)
        val bd = Paint(Paint.ANTI_ALIAS_FLAG)
        bd.style = Paint.Style.STROKE
        bd.strokeWidth = 1.5f * d
        bd.color = Color.argb(t.border * 255 / 100, 255, 255, 255)
        c.drawRoundRect(r, rad, rad, bd)
    }

    fun clockBg(w: Int, h: Int, t: GTheme, d: Float): Bitmap {
        val b = bmp(w, h)
        drawTile(Canvas(b), RectF(d, d, w - d, h - d), t, d)
        return b
    }

    fun batteryBg(w: Int, h: Int, t: GTheme, d: Float, pct: Int): Bitmap {
        val b = bmp(w, h); val c = Canvas(b)
        drawTile(c, RectF(d, d, w - d, h - d), t, d)
        val s = minOf(w, h) * 0.56f; val cx = w / 2f; val cy = h / 2f
        val oval = RectF(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)
        val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        ring.style = Paint.Style.STROKE; ring.strokeWidth = s * 0.12f; ring.strokeCap = Paint.Cap.ROUND
        ring.color = Color.argb(70, Color.red(t.ink), Color.green(t.ink), Color.blue(t.ink))
        c.drawArc(oval, 0f, 360f, false, ring)
        ring.color = t.ink
        c.drawArc(oval, -90f, 360f * pct / 100f, false, ring)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = t.ink; tp.textSize = s * 0.3f; tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        c.drawText("$pct%", cx, cy + tp.textSize * 0.35f, tp)
        return b
    }

    fun preview(t: GTheme, w: Int, h: Int, d: Float): Bitmap {
        val b = Walls.bitmap(w, h, t.wall); val c = Canvas(b)
        val pad = 14 * d
        val wide = RectF(pad, pad, w - pad, h * 0.5f)
        drawTile(c, wide, t, d)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = t.ink; tp.textSize = 40 * d; tp.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        c.drawText("10:42", wide.left + 16 * d, wide.centerY() + 14 * d, tp)
        val sz = (w - pad * 2 - 30 * d) / 4f
        val gp = Paint(Paint.ANTI_ALIAS_FLAG)
        gp.color = Color.argb(200, Color.red(t.ink), Color.green(t.ink), Color.blue(t.ink))
        for (i in 0..3) {
            val l = pad + i * (sz + 10 * d); val top = h * 0.58f
            drawTile(c, RectF(l, top, l + sz, top + sz), t, d)
            c.drawCircle(l + sz / 2, top + sz / 2, sz * 0.18f, gp)
        }
        return b
    }

    fun refreshAll(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        for (cls in listOf(ClockWidget::class.java, BatteryWidget::class.java)) {
            val ids = m.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isNotEmpty()) ctx.sendBroadcast(Intent(ctx, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids))
        }
    }
}
