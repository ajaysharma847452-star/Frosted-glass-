package com.glassify.app

import android.app.Activity
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var unlocked = false
    private var draft: GTheme? = null
    private var pv: ImageView? = null
    private var nameBox: EditText? = null
    private val bg = Color.parseColor("#0E1220")
    private val card = Color.parseColor("#1B2136")
    private val acc = Color.parseColor("#6F7FFF")
    private val grey = Color.parseColor("#9AA3BC")
    private val dens: Float get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * dens).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = bg
        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(40))
        sv.addView(root)
        setContentView(sv)
        render()
    }

    private fun tv(t: String, size: Float, col: Int = Color.WHITE): TextView {
        val v = TextView(this); v.text = t; v.textSize = size; v.setTextColor(col); return v
    }

    private fun btn(t: String, fill: Int = card, on: () -> Unit): Button {
        val b = Button(this)
        b.text = t; b.isAllCaps = false; b.setTextColor(Color.WHITE)
        val g = GradientDrawable(); g.setColor(fill); g.cornerRadius = dp(14).toFloat()
        b.background = g
        b.setOnClickListener { on() }
        return b
    }

    private fun add(v: View, top: Int = 8, h: Int = -2) {
        val lp = LinearLayout.LayoutParams(-1, h); lp.topMargin = dp(top); root.addView(v, lp)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun mkDraft(): GTheme {
        val a = Store.active(this)
        return if (a.custom) a else a.copy(id = "c" + System.currentTimeMillis(), name = "My Glass", custom = true)
    }

    private fun drawPreview(t: GTheme) {
        val w = resources.displayMetrics.widthPixels - dp(32)
        pv?.setImageBitmap(Glass.preview(t, w, dp(200), dens))
    }

    private fun dot(col: Int, sel: Boolean, on: () -> Unit): View {
        val v = View(this)
        val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(col)
        g.setStroke(dp(if (sel) 3 else 1), if (sel) Color.WHITE else Color.parseColor("#55FFFFFF"))
        v.background = g; v.setOnClickListener { on() }
        return v
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL
        for (x in v) { val lp = LinearLayout.LayoutParams(dp(40), dp(40)); lp.rightMargin = dp(10); r.addView(x, lp) }
        return r
    }

    private fun slider(label: String, v: Int, min: Int, max: Int, on: (Int) -> Unit) {
        add(tv(label, 13f, grey), 10)
        val sb = SeekBar(this); sb.max = max - min; sb.progress = v - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { on(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        add(sb, 0)
    }

    private fun upd(f: (GTheme) -> GTheme) {
        val n = nameBox?.text?.toString()
        var d = f(draft!!)
        if (n != null) d = d.copy(name = n)
        draft = d; render()
    }

    private fun render() {
        root.removeAllViews()
        val t = if (unlocked && draft != null) draft!! else Store.active(this)
        add(tv("Glassify", 28f), 0)
        add(tv("Frosted glass widgets, wallpaper aur icon pack", 13f, grey), 2)
        val img = ImageView(this); pv = img
        val rb = GradientDrawable(); rb.setColor(card); rb.cornerRadius = dp(20).toFloat()
        img.background = rb; img.clipToOutline = true
        add(img, 14, dp(200)); drawPreview(t)

        add(tv("Themes", 18f), 22)
        val act = Store.active(this).id
        for (th in Store.all(this)) add(btn((if (th.id == act) "\u2713  " else "") + th.name, if (th.id == act) acc else card) {
            Store.setActive(this, th.id); draft = if (unlocked) mkDraft() else null
            Glass.refreshAll(this); render()
        }, 6)

        add(tv("Phone par apply karo", 18f), 22)
        add(btn("Clock widget add karo") { pin(ClockWidget::class.java) }, 6)
        add(btn("Battery widget add karo") { pin(BatteryWidget::class.java) }, 6)
        add(btn("Glass wallpaper lagao") { setWall(t) }, 6)
        add(btn("Icon pack apply karo (Nova Launcher)") { applyIcons() }, 6)
        add(tv("Icon pack sirf Nova jaise icon-pack support karne wale launcher me chalta hai.", 12f, grey), 4)

        add(tv("Admin Studio", 18f), 26)
        if (!unlocked) {
            val p = EditText(this)
            p.hint = "PIN (default 1234)"; p.setHintTextColor(grey); p.setTextColor(Color.WHITE)
            p.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            add(p, 6)
            add(btn("Unlock", acc) {
                if (p.text.toString() == Store.pin(this)) { unlocked = true; draft = mkDraft(); render() } else toast("Galat PIN")
            }, 6)
            return
        }
        val dr = draft!!
        add(tv("Theme name", 13f, grey), 8)
        val nm = EditText(this); nm.setText(dr.name); nm.setTextColor(Color.WHITE); nm.setSingleLine()
        nameBox = nm; add(nm, 0)
        add(tv("Wallpaper", 13f, grey), 10)
        add(row(*Array(Walls.names.size) { i -> dot(Walls.accent(i), dr.wall == i) { upd { it.copy(wall = i) } } }), 6)
        slider("Transparency", dr.alpha, 2, 60) { draft = draft!!.copy(alpha = it); drawPreview(draft!!) }
        slider("Border glow", dr.border, 0, 80) { draft = draft!!.copy(border = it); drawPreview(draft!!) }
        slider("Roundness", dr.radius, 0, 50) { draft = draft!!.copy(radius = it); drawPreview(draft!!) }
        add(tv("Glass tint", 13f, grey), 10)
        val tints = listOf("#FFFFFF", "#CFE8FF", "#D9FFF0", "#FFD9C2", "#E2D4FF", "#0B1020").map { Color.parseColor(it) }
        add(row(*Array(tints.size) { i -> dot(tints[i], dr.tint == tints[i]) { upd { it.copy(tint = tints[i]) } } }), 6)
        val dark = Color.parseColor("#1A1226")
        add(btn("Icon colour: " + (if (dr.ink == dark) "Dark" else "White")) {
            upd { it.copy(ink = if (it.ink == dark) Color.WHITE else dark) }
        }, 12)
        add(btn("Save to store", acc) {
            val saved = draft!!.copy(name = nm.text.toString().trim().ifEmpty { "My Glass" }, custom = true)
            Store.save(this, saved); Store.setActive(this, saved.id); draft = saved
            Glass.refreshAll(this); render(); toast("Save ho gaya")
        }, 12)
        if (Store.customs(this).any { it.id == dr.id }) add(btn("Delete this theme") {
            Store.delete(this, dr.id); Store.setActive(this, "frost"); draft = mkDraft()
            Glass.refreshAll(this); render()
        }, 6)
        val np = EditText(this)
        np.hint = "Naya PIN (4 se 8 ank)"; np.setHintTextColor(grey); np.setTextColor(Color.WHITE)
        np.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        add(np, 14)
        add(btn("PIN badlo") {
            val v = np.text.toString()
            if (v.length in 4..8) { Store.setPin(this, v); toast("PIN badal gaya") } else toast("4 se 8 ank chahiye")
        }, 6)
        add(btn("Lock") { unlocked = false; draft = null; render() }, 6)
    }

    private fun pin(c: Class<*>) {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) m.requestPinAppWidget(ComponentName(this, c), null, null)
        else toast("Launcher pin support nahi karta. Home screen long-press > Widgets > Glassify se add karo.")
    }

    private fun setWall(t: GTheme) {
        toast("Wallpaper ban raha hai...")
        val dm = resources.displayMetrics
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(Walls.bitmap(dm.widthPixels, dm.heightPixels, t.wall))
                runOnUiThread { toast("Wallpaper lag gaya") }
            } catch (e: Exception) { runOnUiThread { toast("Wallpaper set nahi hua") } }
        }.start()
    }

    private fun applyIcons() {
        try {
            startActivity(Intent("com.teslacoilsw.launcher.APPLY_ICON_THEME").setPackage("com.teslacoilsw.launcher")
                .putExtra("com.teslacoilsw.launcher.extra.ICON_THEME_TYPE", "GO")
                .putExtra("com.teslacoilsw.launcher.extra.ICON_THEME_PACKAGE", packageName))
        } catch (e: Exception) {
            toast("Nova Launcher install karo, phir Nova Settings > Look & feel > Icon style > Icon theme me Glassify chuno")
        }
    }
}
